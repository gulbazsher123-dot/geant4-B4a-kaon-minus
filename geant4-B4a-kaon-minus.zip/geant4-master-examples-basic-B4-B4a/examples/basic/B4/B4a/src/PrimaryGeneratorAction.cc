//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file PrimaryGeneratorAction.cc
/// \brief Implementation of the B4::PrimaryGeneratorAction class
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] Particle: "e-" (electron) --> "kaon-" (K-)
//       Document Sec 4.8: K- kaon minus simulation
//       K- properties: mass=493.68 MeV/c2, charge=-1e, strangeness=-1
//       K- EM: ionization via G4ICRU73QOModel (below 1.05 MeV),
//              Bethe-Bloch above; Barkas effect gives 3-5% lower
//              stopping power than K+ below 5 MeV
//   [2] Energy: 300 MeV UNCHANGED
//       300 MeV K- in water: well above crossover (1.05 MeV),
//       Bethe-Bloch regime, CSDA range ~28-30 cm
// ============================================================

#include "PrimaryGeneratorAction.hh"

#include "G4Box.hh"
#include "G4LogicalVolume.hh"
#include "G4LogicalVolumeStore.hh"
#include "G4ParticleGun.hh"
#include "G4ParticleTable.hh"
#include "G4SystemOfUnits.hh"
#include "globals.hh"

namespace B4
{

PrimaryGeneratorAction::PrimaryGeneratorAction()
{
  G4int nofParticles = 1;
  fParticleGun = new G4ParticleGun(nofParticles);

  // [CHANGE 1] K- kaon minus
  // Geant4 particle name: "kaon-"
  // Document Sec 4.8.1: K- simulation, Barkas effect, ICRU73QO model
  auto particleDefinition =
      G4ParticleTable::GetParticleTable()->FindParticle("kaon-"); // <-- CHANGED

  fParticleGun->SetParticleDefinition(particleDefinition);
  fParticleGun->SetParticleMomentumDirection(G4ThreeVector(0., 0., 1.));

  // [CHANGE 2] Energy: 300 MeV — UNCHANGED from original
  // 300 MeV K- is in Bethe-Bloch regime (well above 1.05 MeV crossover)
  // K- ionization in water: -dE/dx follows 1/beta^2 Bethe-Bloch
  fParticleGun->SetParticleEnergy(300. * MeV); // unchanged
}

PrimaryGeneratorAction::~PrimaryGeneratorAction()
{
  delete fParticleGun;
}

void PrimaryGeneratorAction::GeneratePrimaries(G4Event* event)
{
  // UNCHANGED from original
  G4double worldZHalfLength = 0.;
  auto worldLV = G4LogicalVolumeStore::GetInstance()->GetVolume("World");

  G4Box* worldBox = nullptr;
  if (worldLV) worldBox = dynamic_cast<G4Box*>(worldLV->GetSolid());

  if (worldBox) {
    worldZHalfLength = worldBox->GetZHalfLength();
  }
  else {
    G4ExceptionDescription msg;
    msg << "World volume of box shape not found." << G4endl;
    msg << "Perhaps you have changed geometry." << G4endl;
    msg << "The gun will be place in the center.";
    G4Exception("PrimaryGeneratorAction::GeneratePrimaries()",
                "MyCode0002", JustWarning, msg);
  }

  fParticleGun->SetParticlePosition(G4ThreeVector(0., 0., -worldZHalfLength));
  fParticleGun->GeneratePrimaryVertex(event);
}

}  // namespace B4
