//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file DetectorConstruction.cc
/// \brief Implementation of the B4::DetectorConstruction class
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] Absorber material: "G4_Pb" (Lead) --> "G4_WATER" (water)
//       Document Sec 4.8: "K- stopping power in water"
//       Water is the standard medium for kaon range/stopping power
//       studies (clinical relevance, ICRU-73 reference data in water)
//   [2] Absorber thickness: 10mm --> 30cm
//       K- at 300 MeV has CSDA range ~30 cm in water
//       Need full range contained for stopping power study
//   [3] Gap material: manual liquidArgon --> NIST "G4_lAr"
//       Cleaner, uses NIST evaluated density
//   [4] nofLayers: 10 --> 1
//       Single thick water slab; depth-dose scored by SteppingAction
//   Geometry structure (world/calorimeter/layer/abso/gap) UNCHANGED
// ============================================================

#include "DetectorConstruction.hh"

#include "G4AutoDelete.hh"
#include "G4Box.hh"
#include "G4Colour.hh"
#include "G4GlobalMagFieldMessenger.hh"
#include "G4LogicalVolume.hh"
#include "G4Material.hh"
#include "G4NistManager.hh"
#include "G4PVPlacement.hh"
#include "G4PVReplica.hh"
#include "G4PhysicalConstants.hh"
#include "G4SystemOfUnits.hh"
#include "G4VisAttributes.hh"

namespace B4
{

G4ThreadLocal G4GlobalMagFieldMessenger* DetectorConstruction::fMagFieldMessenger = nullptr;

G4VPhysicalVolume* DetectorConstruction::Construct()
{
  DefineMaterials();
  return DefineVolumes();
}

void DetectorConstruction::DefineMaterials()
{
  auto nistManager = G4NistManager::Instance();

  // [CHANGE 1] Water absorber — document "K- stopping power in water"
  nistManager->FindOrBuildMaterial("G4_WATER");  // <-- CHANGED from "G4_Pb"

  // [CHANGE 3] NIST liquid argon gap
  nistManager->FindOrBuildMaterial("G4_lAr");    // <-- CHANGED from manual liquidArgon

  // Vacuum — UNCHANGED
  G4double a, z, density;
  new G4Material("Galactic", z = 1., a = 1.01 * g / mole,
                 density = universe_mean_density,
                 kStateGas, 2.73 * kelvin, 3.e-18 * pascal);

  G4cout << *(G4Material::GetMaterialTable()) << G4endl;
}

G4VPhysicalVolume* DetectorConstruction::DefineVolumes()
{
  // [CHANGE 4] Single layer — 1 x 30cm water slab
  G4int    nofLayers     = 1;           // <-- CHANGED from 10

  // [CHANGE 2] Water thickness: 30 cm contains full K- range at 300 MeV
  // K- CSDA range in water at 300 MeV ~ 28-30 cm
  G4double absoThickness = 30. * cm;    // <-- CHANGED from 10*mm

  G4double gapThickness  = 5. * mm;     // UNCHANGED
  G4double calorSizeXY   = 10. * cm;    // UNCHANGED

  auto layerThickness = absoThickness + gapThickness;
  auto calorThickness = nofLayers * layerThickness;
  auto worldSizeXY    = 1.2 * calorSizeXY;
  auto worldSizeZ     = 1.2 * calorThickness;

  auto defaultMaterial  = G4Material::GetMaterial("Galactic");
  auto absorberMaterial = G4Material::GetMaterial("G4_WATER"); // [CHANGE 1]
  auto gapMaterial      = G4Material::GetMaterial("G4_lAr");   // [CHANGE 3]

  if (!defaultMaterial || !absorberMaterial || !gapMaterial) {
    G4ExceptionDescription msg;
    msg << "Cannot retrieve materials already defined.";
    G4Exception("DetectorConstruction::DefineVolumes()",
                "MyCode0001", FatalException, msg);
  }

  // World — structure UNCHANGED
  auto worldS  = new G4Box("World",
                            worldSizeXY/2, worldSizeXY/2, worldSizeZ/2);
  auto worldLV = new G4LogicalVolume(worldS, defaultMaterial, "World");
  auto worldPV = new G4PVPlacement(nullptr, G4ThreeVector(), worldLV,
                                   "World", nullptr, false, 0, fCheckOverlaps);

  // Calorimeter — structure UNCHANGED
  auto calorimeterS = new G4Box("Calorimeter",
                                 calorSizeXY/2, calorSizeXY/2, calorThickness/2);
  auto calorLV = new G4LogicalVolume(calorimeterS, defaultMaterial, "Calorimeter");
  new G4PVPlacement(nullptr, G4ThreeVector(), calorLV,
                    "Calorimeter", worldLV, false, 0, fCheckOverlaps);

  // Layer — structure UNCHANGED
  auto layerS  = new G4Box("Layer",
                            calorSizeXY/2, calorSizeXY/2, layerThickness/2);
  auto layerLV = new G4LogicalVolume(layerS, defaultMaterial, "Layer");
  new G4PVReplica("Layer", layerLV, calorLV,
                  kZAxis, nofLayers, layerThickness);

  // Absorber (water) — placement UNCHANGED
  auto absorberS  = new G4Box("Abso",
                               calorSizeXY/2, calorSizeXY/2, absoThickness/2);
  auto absorberLV = new G4LogicalVolume(absorberS, absorberMaterial, "Abso");
  fAbsorberPV = new G4PVPlacement(nullptr,
                    G4ThreeVector(0., 0., -gapThickness/2),
                    absorberLV, "Abso", layerLV, false, 0, fCheckOverlaps);

  // Gap (lAr) — placement UNCHANGED
  auto gapS  = new G4Box("Gap",
                          calorSizeXY/2, calorSizeXY/2, gapThickness/2);
  auto gapLV = new G4LogicalVolume(gapS, gapMaterial, "Gap");
  fGapPV = new G4PVPlacement(nullptr,
               G4ThreeVector(0., 0., absoThickness/2),
               gapLV, "Gap", layerLV, false, 0, fCheckOverlaps);

  // Print parameters
  G4cout << G4endl
         << "------------------------------------------------------------" << G4endl
         << "---> The calorimeter is " << nofLayers << " layer of: [ "
         << absoThickness/cm << " cm of " << absorberMaterial->GetName()
         << " + " << gapThickness/mm << " mm of " << gapMaterial->GetName()
         << " ] " << G4endl
         << "  Particle: K- (kaon minus) 300 MeV" << G4endl
         << "  Physics:  FTFP_BERT + Standard Opt4" << G4endl
         << "  Key:      G4ICRU73QOModel for K- below 1.05 MeV" << G4endl
         << "------------------------------------------------------------" << G4endl;

  // Visualization — UNCHANGED
  worldLV->SetVisAttributes(G4VisAttributes::GetInvisible());
  calorLV->SetVisAttributes(G4VisAttributes(G4Colour::White()));

  return worldPV;
}

void DetectorConstruction::ConstructSDandField()
{
  // UNCHANGED
  G4ThreeVector fieldValue;
  fMagFieldMessenger = new G4GlobalMagFieldMessenger(fieldValue);
  fMagFieldMessenger->SetVerboseLevel(1);
  G4AutoDelete::Register(fMagFieldMessenger);
}

}  // namespace B4
