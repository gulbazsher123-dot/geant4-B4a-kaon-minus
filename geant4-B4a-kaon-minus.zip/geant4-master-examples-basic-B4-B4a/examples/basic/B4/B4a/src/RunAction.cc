//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file RunAction.cc
/// \brief Implementation of the B4::RunAction class
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] Histogram ranges updated for K- in water at 300 MeV:
//       H1(0) Eabs: 0-350 MeV (K- 300 MeV deposits up to 300 MeV)
//       H1(2) Labs: 0-35 cm  (K- range ~28-30 cm in water)
//   [2] Added 4 new histograms (indices 4-7):
//       H1(4) Theta  — K- MSC polar exit angle
//       H1(5) Phi    — K- azimuthal angle (expect flat, azimuthal sym)
//       H1(6) SecEdep— secondary particle edep (delta-rays, decay prods)
//       H1(7) Nsec   — number of secondaries per event
//   [3] Added 4 new ntuple columns (cols 4-7)
//   [4] Output filename: "B4.root" --> "B4a_Water_Kaon_Opt4.root"
//   Original H1(0-3) + ntuple cols 0-3 structure UNCHANGED
// ============================================================

#include "RunAction.hh"

#include "G4AnalysisManager.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"
#include "globals.hh"

namespace B4
{

RunAction::RunAction()
{
  G4RunManager::GetRunManager()->SetPrintProgress(1);

  auto analysisManager = G4AnalysisManager::Instance();
  analysisManager->SetVerboseLevel(1);
  analysisManager->SetNtupleMerging(true);

  // ORIGINAL 4 histograms — kept, ranges updated for K- in water [CHANGE 1]
  // H1(0): Energy deposit in water absorber
  // K- 300 MeV: deposits up to 300 MeV (full stop) or partial
  analysisManager->CreateH1("Eabs",
      "Edep in absorber (H2O) — K- 300 MeV",
      110, 0., 350.*MeV);     // <-- range changed (was 330 MeV)

  // H1(1): Energy deposit in lAr gap — UNCHANGED range
  analysisManager->CreateH1("Egap",
      "Edep in gap (lAr)",
      100, 0., 30.*MeV);      // unchanged

  // H1(2): Track length in water — K- range ~28-30 cm
  analysisManager->CreateH1("Labs",
      "trackL in absorber (H2O)",
      100, 0., 35.*cm);       // <-- range changed (was 50 cm)

  // H1(3): Track length in gap — UNCHANGED
  analysisManager->CreateH1("Lgap",
      "trackL in gap (lAr)",
      100, 0., 50.*cm);       // unchanged

  // [CHANGE 2] New histograms 4-7

  // H1(4): K- MSC polar exit angle
  // K- is heavy (493 MeV/c2) => small MSC angle in water
  analysisManager->CreateH1("Theta",
      "K- MSC exit polar angle (rad) — Opt4 WentzelVI",
      90, 0., 10.*CLHEP::deg); // K- scatters less than pi-

  // H1(5): Azimuthal phi — expect flat (azimuthal symmetry)
  // Document Sec 4.8: symmetry confirmation for unpolarised K- beam
  analysisManager->CreateH1("Phi",
      "K- exit azimuthal phi (rad) — expect uniform",
      36, 0., CLHEP::twopi);

  // H1(6): Secondary particle energy deposit
  // K- secondaries: delta-rays (dominant), K- decay products
  // K- decay modes: K--->mu-+nubar (63.5%), pi-+pi0 (20.7%), etc.
  analysisManager->CreateH1("SecEdep",
      "Secondary particle Edep in H2O (MeV)",
      100, 0., 100.*MeV);

  // H1(7): Number of secondaries per event
  analysisManager->CreateH1("Nsec",
      "Number of secondary particles per event",
      100, 0., 100.);

  // ORIGINAL ntuple — cols 0-3 UNCHANGED
  analysisManager->CreateNtuple("B4", "Edep and TrackL — K- in Water");
  analysisManager->CreateNtupleDColumn("Eabs");    // col 0 — unchanged
  analysisManager->CreateNtupleDColumn("Egap");    // col 1 — unchanged
  analysisManager->CreateNtupleDColumn("Labs");    // col 2 — unchanged
  analysisManager->CreateNtupleDColumn("Lgap");    // col 3 — unchanged

  // [CHANGE 3] New ntuple columns 4-7
  analysisManager->CreateNtupleDColumn("Theta");   // col 4
  analysisManager->CreateNtupleDColumn("Phi");     // col 5
  analysisManager->CreateNtupleDColumn("SecEdep"); // col 6
  analysisManager->CreateNtupleDColumn("Nsec");    // col 7
  analysisManager->FinishNtuple();
}

void RunAction::BeginOfRunAction(const G4Run* /*run*/)
{
  auto analysisManager = G4AnalysisManager::Instance();

  // [CHANGE 4] Descriptive filename
  G4String fileName = "B4a_Water_Kaon_Opt4.root"; // <-- CHANGED from "B4.root"
  analysisManager->OpenFile(fileName);
  G4cout << "Using " << analysisManager->GetType() << G4endl;
  G4cout << "Output: " << fileName << G4endl;
}

void RunAction::EndOfRunAction(const G4Run* /*run*/)
{
  auto analysisManager = G4AnalysisManager::Instance();

  if (analysisManager->GetH1(1)) {
    G4cout << G4endl << " ----> print histograms statistic ";
    if (isMaster) G4cout << "for the entire run " << G4endl << G4endl;
    else          G4cout << "for the local thread " << G4endl << G4endl;

    // ORIGINAL stats — UNCHANGED
    G4cout << " EAbs : mean = "
           << G4BestUnit(analysisManager->GetH1(0)->mean(), "Energy")
           << " rms = "
           << G4BestUnit(analysisManager->GetH1(0)->rms(),  "Energy") << G4endl;
    G4cout << " EGap : mean = "
           << G4BestUnit(analysisManager->GetH1(1)->mean(), "Energy")
           << " rms = "
           << G4BestUnit(analysisManager->GetH1(1)->rms(),  "Energy") << G4endl;
    G4cout << " LAbs : mean = "
           << G4BestUnit(analysisManager->GetH1(2)->mean(), "Length")
           << " rms = "
           << G4BestUnit(analysisManager->GetH1(2)->rms(),  "Length") << G4endl;
    G4cout << " LGap : mean = "
           << G4BestUnit(analysisManager->GetH1(3)->mean(), "Length")
           << " rms = "
           << G4BestUnit(analysisManager->GetH1(3)->rms(),  "Length") << G4endl;

    // [CHANGE 2] New stats
    G4cout << " Theta: mean = "
           << analysisManager->GetH1(4)->mean()/CLHEP::deg << " deg"
           << "  rms = "
           << analysisManager->GetH1(4)->rms()/CLHEP::deg  << " deg" << G4endl;
    G4cout << " Nsec : mean = "
           << analysisManager->GetH1(7)->mean() << G4endl;
  }

  analysisManager->Write();
  analysisManager->CloseFile();
}

}  // namespace B4
