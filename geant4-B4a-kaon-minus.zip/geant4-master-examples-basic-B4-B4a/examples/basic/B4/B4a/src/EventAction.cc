//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file EventAction.cc
/// \brief Implementation of the B4a::EventAction class
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] BeginOfEventAction: reset fTheta=-1, fPhi=0,
//       fSecondaryEdep=0, fNSecondaries=0
//   [2] EndOfEventAction: fill H1(4)=Theta, H1(5)=Phi,
//       H1(6)=SecEdep, H1(7)=Nsec
//   [3] Ntuple: fill cols 4-7 (Theta,Phi,SecEdep,Nsec)
//   Original H1(0-3) fills + ntuple cols 0-3 ALL UNCHANGED
// ============================================================

#include "EventAction.hh"

#include "G4AnalysisManager.hh"
#include "G4Event.hh"
#include "G4RunManager.hh"
#include "G4SystemOfUnits.hh"
#include "G4UnitsTable.hh"

#include <iomanip>

namespace B4a
{

void EventAction::BeginOfEventAction(const G4Event* /*event*/)
{
  // ORIGINAL resets — UNCHANGED
  fEnergyAbs = 0.;
  fEnergyGap = 0.;
  fTrackLAbs = 0.;
  fTrackLGap = 0.;

  // [CHANGE 1] Reset new accumulators
  fTheta         = -1.;
  fPhi           =  0.;
  fSecondaryEdep =  0.;
  fNSecondaries  =  0;
}

void EventAction::EndOfEventAction(const G4Event* event)
{
  auto analysisManager = G4AnalysisManager::Instance();

  // ORIGINAL histogram fills — UNCHANGED (H1 indices 0-3)
  analysisManager->FillH1(0, fEnergyAbs);
  analysisManager->FillH1(1, fEnergyGap);
  analysisManager->FillH1(2, fTrackLAbs);
  analysisManager->FillH1(3, fTrackLGap);

  // [CHANGE 2] New histogram fills (H1 indices 4-7)
  if (fTheta >= 0.) {
    analysisManager->FillH1(4, fTheta);  // K- MSC polar angle
    analysisManager->FillH1(5, fPhi);    // K- azimuthal angle
  }
  analysisManager->FillH1(6, fSecondaryEdep);
  analysisManager->FillH1(7, (G4double)fNSecondaries);

  // ORIGINAL ntuple fills — UNCHANGED (cols 0-3)
  analysisManager->FillNtupleDColumn(0, fEnergyAbs);
  analysisManager->FillNtupleDColumn(1, fEnergyGap);
  analysisManager->FillNtupleDColumn(2, fTrackLAbs);
  analysisManager->FillNtupleDColumn(3, fTrackLGap);

  // [CHANGE 3] New ntuple columns (cols 4-7)
  analysisManager->FillNtupleDColumn(4, fTheta);
  analysisManager->FillNtupleDColumn(5, fPhi);
  analysisManager->FillNtupleDColumn(6, fSecondaryEdep);
  analysisManager->FillNtupleDColumn(7, (G4double)fNSecondaries);
  analysisManager->AddNtupleRow();

  // Print per event — extended with new fields
  auto eventID     = event->GetEventID();
  auto printModulo = G4RunManager::GetRunManager()->GetPrintProgress();
  if ((printModulo > 0) && (eventID % printModulo == 0)) {
    G4cout << "   Absorber(H2O): energy: "
           << std::setw(7) << G4BestUnit(fEnergyAbs, "Energy")
           << "   track length: "
           << std::setw(7) << G4BestUnit(fTrackLAbs, "Length") << G4endl
           << "   Gap(lAr):      energy: "
           << std::setw(7) << G4BestUnit(fEnergyGap, "Energy")
           << "   track length: "
           << std::setw(7) << G4BestUnit(fTrackLGap, "Length") << G4endl;
    if (fTheta >= 0.)
      G4cout << "   K- exit: Theta=" << fTheta/CLHEP::deg << " deg"
             << "  Phi=" << fPhi/CLHEP::deg << " deg" << G4endl;
    G4cout << "   Secondaries: N=" << fNSecondaries
           << "  Edep=" << G4BestUnit(fSecondaryEdep, "Energy") << G4endl;
    G4cout << "--> End of event " << eventID << "\n" << G4endl;
  }
}

}  // namespace B4a
