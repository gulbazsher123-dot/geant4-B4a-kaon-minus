//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file SteppingAction.cc
/// \brief Implementation of the B4a::SteppingAction class
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] Volume check: PV pointer --> LV name "Abso"/"Gap"
//       Fixes scoring failure with G4PVReplica geometry
//   [2] Primary (trackID==1) vs secondary split in absorber
//   [3] K- exit angle scoring (theta, phi) when primary exits
//   Original energy deposit + step length collection UNCHANGED
// ============================================================

#include "SteppingAction.hh"

#include "DetectorConstruction.hh"
#include "EventAction.hh"

#include "G4LogicalVolume.hh"
#include "G4Step.hh"
#include "G4SystemOfUnits.hh"
#include "globals.hh"

#include <cmath>

using namespace B4;

namespace B4a
{

SteppingAction::SteppingAction(const DetectorConstruction* detConstruction,
                               EventAction* eventAction)
  : fDetConstruction(detConstruction), fEventAction(eventAction)
{}

void SteppingAction::UserSteppingAction(const G4Step* step)
{
  // [CHANGE 1] Get LV name — works with G4PVReplica
  auto prePoint = step->GetPreStepPoint();
  auto volume   = prePoint->GetTouchableHandle()->GetVolume();
  if (!volume) return;
  auto lvName = volume->GetLogicalVolume()->GetName();

  // ORIGINAL: energy deposit + step length — logic UNCHANGED
  auto edep = step->GetTotalEnergyDeposit();

  G4double stepLength = 0.;
  if (step->GetTrack()->GetDefinition()->GetPDGCharge() != 0.)
    stepLength = step->GetStepLength();

  G4int trackID = step->GetTrack()->GetTrackID();

  // ── ABSORBER (water) ──────────────────────────────────────
  // [CHANGE 1] LV name "Abso" instead of GetAbsorberPV() pointer
  if (lvName == "Abso") {

    if (trackID == 1) {
      // Primary K- — ORIGINAL AddAbs call unchanged
      fEventAction->AddAbs(edep, stepLength);

      // [CHANGE 3] Record exit angle when K- leaves absorber
      auto postVolume = step->GetPostStepPoint()
                            ->GetTouchableHandle()->GetVolume();
      G4bool leaving = (!postVolume) ||
                       (postVolume->GetLogicalVolume()->GetName() != "Abso");

      if (leaving && step->GetTrack()->GetKineticEnergy() > 0.) {
        auto dir   = step->GetTrack()->GetMomentumDirection();
        G4double theta = std::acos(std::min(1.0, std::abs(dir.z())));
        G4double phi   = std::atan2(dir.y(), dir.x());
        if (phi < 0.) phi += CLHEP::twopi;
        fEventAction->SetTheta(theta);
        fEventAction->SetPhi(phi);
      }

    } else {
      // [CHANGE 2] Secondary particles
      // K- secondaries: delta-rays (e-), K- decay products
      fEventAction->AddSecondaryEdep(edep);
      if (step->GetTrack()->GetCurrentStepNumber() == 1)
        fEventAction->AddSecondary();
    }
  }

  // ── GAP (liquid argon) ────────────────────────────────────
  // [CHANGE 1] LV name "Gap" instead of GetGapPV() pointer
  if (lvName == "Gap") {
    if (trackID == 1) {
      // Primary K- in gap — ORIGINAL AddGap call unchanged
      fEventAction->AddGap(edep, stepLength);
    }
  }
}

}  // namespace B4a
