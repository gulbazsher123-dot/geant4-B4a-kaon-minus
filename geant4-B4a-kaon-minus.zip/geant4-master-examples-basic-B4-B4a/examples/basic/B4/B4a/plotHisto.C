// ============================================================
// plotHisto.C — B4a K- Kaon Simulation (FTFP_BERT + Opt4)
// CHANGES FROM ORIGINAL:
//   [1] Named function void plotHisto() — fixes ROOT 6 warning
//   [2] Filename: "B4a_Water_Kaon_Opt4.root"
//   [3] Canvas 1: original 4 histograms (UNCHANGED layout)
//   [4] Canvas 2: new 4 histograms (Theta, Phi, SecEdep, Nsec)
// ============================================================

void plotHisto(const char* fname = "B4a_Water_Kaon_Opt4.root")
{
  gROOT->Reset();
  gROOT->SetStyle("Plain");
  gStyle->SetOptStat(1110);

  TFile* f = TFile::Open(fname);
  if (!f || f->IsZombie()) {
    std::cout << "ERROR: Cannot open " << fname << std::endl;
    std::cout << "Run simulation first: exampleB4a -m run1.mac" << std::endl;
    return;
  }
  std::cout << "Opened: " << fname << std::endl;

  // ── Canvas 1: ORIGINAL 4 histograms (UNCHANGED layout) ───
  TCanvas* c1 = new TCanvas("c1","K- in Water — Energy and Track",10,10,1000,1000);
  c1->Divide(2,2);

  c1->cd(1);
  TH1D* hEabs = (TH1D*)f->Get("Eabs");
  if (hEabs) {
    hEabs->SetFillColor(kBlue-9);
    hEabs->GetXaxis()->SetTitle("Energy deposit [MeV]");
    hEabs->GetYaxis()->SetTitle("Events");
    hEabs->SetTitle("K^{-} Edep in H_{2}O absorber");
    hEabs->Draw("HIST");
  }

  c1->cd(2);
  TH1D* hEgap = (TH1D*)f->Get("Egap");
  if (hEgap) {
    hEgap->SetFillColor(kYellow-9);
    hEgap->GetXaxis()->SetTitle("Energy deposit [MeV]");
    hEgap->GetYaxis()->SetTitle("Events");
    hEgap->SetTitle("K^{-} Edep in lAr gap");
    hEgap->Draw("HIST");
  }

  c1->cd(3);
  TH1D* hLabs = (TH1D*)f->Get("Labs");
  if (hLabs) {
    hLabs->SetFillColor(kRed-9);
    hLabs->GetXaxis()->SetTitle("Track length [cm]");
    hLabs->GetYaxis()->SetTitle("Events");
    hLabs->SetTitle("K^{-} track length in H_{2}O");
    hLabs->Draw("HIST");
  }

  c1->cd(4);
  TH1D* hLgap = (TH1D*)f->Get("Lgap");
  if (hLgap) {
    hLgap->SetFillColor(kGreen-9);
    hLgap->GetXaxis()->SetTitle("Track length [cm]");
    hLgap->GetYaxis()->SetTitle("Events");
    hLgap->SetTitle("K^{-} track length in lAr gap");
    hLgap->Draw("HIST");
  }

  c1->Update();
  c1->Print("Kaon_energy_track.png");

  // ── Canvas 2: NEW histograms — Theta, Phi, Secondary ─────
  TCanvas* c2 = new TCanvas("c2","K- Angular and Secondary",20,20,1000,1000);
  c2->Divide(2,2);

  // H1(4): K- MSC polar exit angle
  c2->cd(1);
  TH1D* hTheta = (TH1D*)f->Get("Theta");
  if (hTheta) {
    hTheta->SetLineColor(kBlue);
    hTheta->SetLineWidth(2);
    hTheta->GetXaxis()->SetTitle("#theta [deg]");
    hTheta->GetYaxis()->SetTitle("Events");
    hTheta->SetTitle("K^{-} MSC exit polar angle #theta (Opt4 WentzelVI)");
    hTheta->Draw("HIST");
  }

  // H1(5): Azimuthal phi — expect flat (confirms azimuthal symmetry)
  c2->cd(2);
  TH1D* hPhi = (TH1D*)f->Get("Phi");
  if (hPhi) {
    hPhi->SetLineColor(kRed);
    hPhi->SetLineWidth(2);
    hPhi->GetXaxis()->SetTitle("#phi [rad]");
    hPhi->GetYaxis()->SetTitle("Events");
    hPhi->SetTitle("K^{-} azimuthal #phi — expect flat (azimuthal symmetry)");
    hPhi->Fit("pol0","Q");
    hPhi->Draw("HIST");
    if (hPhi->GetFunction("pol0"))
      hPhi->GetFunction("pol0")->SetLineColor(kBlack);
  }

  // H1(6): Secondary edep — delta-rays + K- decay products
  c2->cd(3);
  TH1D* hSec = (TH1D*)f->Get("SecEdep");
  if (hSec) {
    hSec->SetFillColor(kMagenta-9);
    hSec->GetXaxis()->SetTitle("Secondary Edep [MeV]");
    hSec->GetYaxis()->SetTitle("Events");
    hSec->SetTitle("Secondary particle Edep (delta-rays + K^{-} decay)");
    hSec->Draw("HIST");
  }

  // H1(7): Number of secondaries
  c2->cd(4);
  TH1D* hNsec = (TH1D*)f->Get("Nsec");
  if (hNsec) {
    hNsec->SetFillColor(kCyan-9);
    hNsec->GetXaxis()->SetTitle("N secondaries");
    hNsec->GetYaxis()->SetTitle("Events");
    hNsec->SetTitle("Number of secondaries per event");
    hNsec->Draw("HIST");
  }

  c2->Update();
  c2->Print("Kaon_angular_secondary.png");

  std::cout << "Saved: Kaon_energy_track.png + Kaon_angular_secondary.png" << std::endl;
}
