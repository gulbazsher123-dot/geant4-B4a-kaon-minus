//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file EventAction.hh
/// \brief Definition of the B4a::EventAction class
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] Added: fTheta, fPhi — K- exit MSC angles
//       Document: stopping power study needs angular info
//   [2] Added: fSecondaryEdep, fNSecondaries — secondary tracking
//       Secondaries from K-: delta-rays (e-), K- decay products
//       (K- --> mu- + nubar, pi- + pi0, etc.)
//   [3] Added: SetTheta(), SetPhi(), AddSecondaryEdep(), AddSecondary()
//   Original members/methods fEnergyAbs, fEnergyGap,
//   fTrackLAbs, fTrackLGap, AddAbs(), AddGap() ALL UNCHANGED
// ============================================================

#ifndef B4aEventAction_h
#define B4aEventAction_h 1

#include "G4UserEventAction.hh"
#include "globals.hh"

class G4Event;

namespace B4a
{

class EventAction : public G4UserEventAction
{
  public:
    EventAction() = default;
    ~EventAction() override = default;

    void BeginOfEventAction(const G4Event* event) override;
    void EndOfEventAction(const G4Event* event) override;

    // ORIGINAL methods — UNCHANGED
    void AddAbs(G4double de, G4double dl);
    void AddGap(G4double de, G4double dl);

    // [CHANGE 1] K- exit angle setters
    void SetTheta(G4double theta);
    void SetPhi(G4double phi);

    // [CHANGE 2] Secondary particle scoring
    void AddSecondaryEdep(G4double de);
    void AddSecondary();

  private:
    // ORIGINAL members — UNCHANGED
    G4double fEnergyAbs = 0.;
    G4double fEnergyGap = 0.;
    G4double fTrackLAbs = 0.;
    G4double fTrackLGap = 0.;

    // [CHANGE 1] K- exit angles
    G4double fTheta = -1.;   // -1 = K- stopped inside (did not exit)
    G4double fPhi   =  0.;

    // [CHANGE 2] Secondary particle accumulators
    G4double fSecondaryEdep = 0.;
    G4int    fNSecondaries  = 0;
};

// ORIGINAL inlines — UNCHANGED
inline void EventAction::AddAbs(G4double de, G4double dl)
{ fEnergyAbs += de; fTrackLAbs += dl; }

inline void EventAction::AddGap(G4double de, G4double dl)
{ fEnergyGap += de; fTrackLGap += dl; }

// [CHANGE 1] New inlines
inline void EventAction::SetTheta(G4double t) { fTheta = t; }
inline void EventAction::SetPhi(G4double p)   { fPhi   = p; }

// [CHANGE 2] New inlines
inline void EventAction::AddSecondaryEdep(G4double de) { fSecondaryEdep += de; }
inline void EventAction::AddSecondary()                { fNSecondaries++;       }

}  // namespace B4a

#endif
