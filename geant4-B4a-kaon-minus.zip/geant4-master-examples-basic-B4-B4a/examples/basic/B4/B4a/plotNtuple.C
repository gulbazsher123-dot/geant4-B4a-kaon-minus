// ============================================================
// plotNtuple.C — B4a K- Kaon Simulation
// CHANGES FROM ORIGINAL:
//   [1] Named function void plotNtuple() — fixes ROOT 6 warning
//   [2] Filename: "B4a_Water_Kaon_Opt4.root"
//   [3] Canvas 1: original 4 columns (UNCHANGED)
//   [4] Canvas 2: new 4 columns (Theta,Phi,SecEdep,Nsec)
// ============================================================

void plotNtuple(const char* fname = "B4a_Water_Kaon_Opt4.root")
{
  gROOT->Reset();
  gROOT->SetStyle("Plain");

  TFile* f = TFile::Open(fname);
  if (!f || f->IsZombie()) {
    std::cout << "ERROR: Cannot open " << fname << std::endl;
    return;
  }

  TTree* ntuple = (TTree*)f->Get("B4");
  if (!ntuple) {
    std::cout << "ERROR: ntuple B4 not found!" << std::endl;
    return;
  }
  std::cout << "Entries: " << ntuple->GetEntries() << std::endl;

  // Canvas 1: original 4 columns — UNCHANGED layout
  TCanvas* c1 = new TCanvas("c1","K- Ntuple original cols",10,10,1000,1000);
  c1->Divide(2,2);
  c1->cd(1); ntuple->Draw("Eabs>>hEa(110,0,350)","","");
  c1->cd(2); ntuple->Draw("Egap>>hEg(100,0,30)","","");
  c1->cd(3); ntuple->Draw("Labs>>hLa(100,0,35)","","");
  c1->cd(4); ntuple->Draw("Lgap>>hLg(100,0,50)","","");
  c1->Update();
  c1->Print("Kaon_ntuple_original.png");

  // Canvas 2: new 4 columns
  TCanvas* c2 = new TCanvas("c2","K- Ntuple new cols",20,20,1000,1000);
  c2->Divide(2,2);

  c2->cd(1);
  ntuple->Draw("Theta*180/3.14159>>hT(90,0,10)","Theta>=0","");
  TH1* ht = (TH1*)gPad->GetPrimitive("hT");
  if (ht) ht->SetTitle("K^{-} exit #theta [deg]");

  c2->cd(2);
  ntuple->Draw("Phi>>hP(36,0,6.2832)","Theta>=0","");
  TH1* hp = (TH1*)gPad->GetPrimitive("hP");
  if (hp) { hp->SetTitle("K^{-} exit #phi [rad] — expect flat"); hp->Fit("pol0","Q"); }

  c2->cd(3);
  ntuple->Draw("SecEdep>>hS(100,0,100)","","");
  TH1* hs = (TH1*)gPad->GetPrimitive("hS");
  if (hs) hs->SetTitle("Secondary Edep [MeV]");

  c2->cd(4);
  ntuple->Draw("Nsec>>hN(50,0,50)","","");
  TH1* hn = (TH1*)gPad->GetPrimitive("hN");
  if (hn) hn->SetTitle("N secondaries per event");

  c2->Update();
  c2->Print("Kaon_ntuple_new.png");

  std::cout << "Saved: Kaon_ntuple_original.png + Kaon_ntuple_new.png" << std::endl;
}
