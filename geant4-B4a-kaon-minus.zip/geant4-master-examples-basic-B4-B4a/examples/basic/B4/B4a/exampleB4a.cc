//
// ********************************************************************
// * License and Disclaimer  (Geant4 standard — unchanged)            *
// ********************************************************************
//
/// \file exampleB4a.cc
/// \brief Main program — B4a K- Kaon Simulation
//
// ============================================================
// CHANGES FROM ORIGINAL B4a:
//   [1] Added: #include "G4EmStandardPhysics_option4.hh"
//       Standard Opt4 EM physics (WentzelVI MSC, best accuracy)
//       Document Sec 4.8: "Opt4 within 3% above 10 MeV"
//   [2] Added: physicsList->ReplacePhysics(new G4EmStandardPhysics_option4())
//       Replaces default EM in FTFP_BERT with Opt4
//       FTFP_BERT hadronic (kaon inelastic) unchanged
// ============================================================

#include "ActionInitialization.hh"
#include "DetectorConstruction.hh"
#include "FTFP_BERT.hh"
#include "G4EmStandardPhysics_option4.hh"   // [CHANGE 1] Opt4 EM

#include "G4RunManagerFactory.hh"
#include "G4SteppingVerbose.hh"
#include "G4UIExecutive.hh"
#include "G4UIcommand.hh"
#include "G4UImanager.hh"
#include "G4VisExecutive.hh"

namespace
{
void PrintUsage()
{
  G4cerr << " Usage: " << G4endl;
  G4cerr << " exampleB4a [-m macro ] [-u UIsession] [-t nThreads] [-vDefault]" << G4endl;
  G4cerr << "   note: -t option is available only for multi-threaded mode." << G4endl;
}
}

int main(int argc, char** argv)
{
  if (argc > 7) { PrintUsage(); return 1; }

  G4String macro;
  G4String session;
  G4bool verboseBestUnits = true;
#ifdef G4MULTITHREADED
  G4int nThreads = 0;
#endif

  for (G4int i = 1; i < argc; i = i + 2) {
    if      (G4String(argv[i]) == "-m") macro   = argv[i + 1];
    else if (G4String(argv[i]) == "-u") session = argv[i + 1];
#ifdef G4MULTITHREADED
    else if (G4String(argv[i]) == "-t") nThreads = G4UIcommand::ConvertToInt(argv[i + 1]);
#endif
    else if (G4String(argv[i]) == "-vDefault") { verboseBestUnits = false; --i; }
    else { PrintUsage(); return 1; }
  }

  G4UIExecutive* ui = nullptr;
  if (!macro.size()) ui = new G4UIExecutive(argc, argv, session);

  if (verboseBestUnits) {
    G4int precision = 4;
    G4SteppingVerbose::UseBestUnit(precision);
  }

  auto runManager = G4RunManagerFactory::CreateRunManager(G4RunManagerType::Default);
#ifdef G4MULTITHREADED
  if (nThreads > 0) runManager->SetNumberOfThreads(nThreads);
#endif

  auto detConstruction = new B4::DetectorConstruction();
  runManager->SetUserInitialization(detConstruction);

  // [CHANGE 2] FTFP_BERT + Standard Opt4 EM
  // Document: "Opt4 within 3% above 10 MeV" for K- stopping power in water
  // Opt4 uses WentzelVI MSC + G4ICRU73QOModel for K- ionization below crossover
  auto physicsList = new FTFP_BERT;
  physicsList->ReplacePhysics(new G4EmStandardPhysics_option4()); // <-- CHANGED
  runManager->SetUserInitialization(physicsList);

  auto actionInitialization = new B4a::ActionInitialization(detConstruction);
  runManager->SetUserInitialization(actionInitialization);

  auto visManager = new G4VisExecutive;
  visManager->Initialize();

  auto UImanager = G4UImanager::GetUIpointer();

  if (macro.size()) {
    G4String command = "/control/execute ";
    UImanager->ApplyCommand(command + macro);
  }
  else {
    UImanager->ApplyCommand("/control/execute init_vis.mac");
    if (ui->IsGUI()) UImanager->ApplyCommand("/control/execute gui.mac");
    ui->SessionStart();
    delete ui;
  }

  delete visManager;
  delete runManager;
}
